using System;
using System.Collections;
using System.Collections.Generic;
using Game.Runtime.Core;
using Game.Runtime.Data;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Serialization;

public class Player : MonoBehaviour
{
    // 删除切换人物功能
    // public Character currentCharacter;

    [HideInInspector] public Rigidbody2D rb;
    [HideInInspector] public PhysicsDetection physics;
    public Animator anim;
    public Animator catAnim;
    public Animator shadow;
    private SpriteRenderer spriteRenderer;

    public float moveSpeed;
    public float jumpForce;



#region InputSystem

    public InputActionAsset inputActions;
    public Vector2 moveInputValue { get; private set; }
    public InputAction moveAction { get; private set; }
    public InputAction jumpAction { get; private set; }
    public InputAction interactAction { get; private set; }

#endregion

#region PlayerState 角色状态机

    private PlayerStateMachine stateMachine;
    public PlayerIdleState idleState { get; private set; }
    public PlayerMoveState moveState { get; private set; }
    public PlayerJumpState jumpState { get; private set; }
    public PlayerAirState airState { get; private set; }

#endregion


    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        physics = GetComponent<PhysicsDetection>();
        //anim = GetComponentInChildren<Animator>();
        spriteRenderer = GetComponentInChildren<SpriteRenderer>();

        stateMachine = new PlayerStateMachine();
        idleState = new PlayerIdleState(this, stateMachine, "idle");
        moveState = new PlayerMoveState(this, stateMachine, "move");
        jumpState = new PlayerJumpState(this, stateMachine, "jump");
        airState = new PlayerAirState(this, stateMachine, "jump");
    }

    void Start()
    {
        moveAction = InputSystem.actions.FindAction("Move");
        jumpAction = InputSystem.actions.FindAction("Jump");
        interactAction = InputSystem.actions.FindAction("Interact");
        stateMachine.Initialize(idleState);
        //SwitchCharacter(Character.Player);
    }


    void Update()
    {
        moveInputValue = moveAction.ReadValue<Vector2>();
        stateMachine.currentState.Update();
    }

    public void SetSpawnPosition(Vector3 position)
    {
        transform.position = position;
        stateMachine.Initialize(idleState);
    }


#region 切换角色

    // public void SwitchCharacter()
    // {
    //     Character newCharacter = currentCharacter == Character.Player ? Character.Cat : Character.Player;
    //     SwitchCharacter(newCharacter);
    // }
    //
    // private void SwitchCharacter(Character character)
    // {
    //     if (currentCharacter == character) return;
    //     Debug.Log($"SwitchCharacter -> {character}");
    //     currentCharacter = character;
    //     switch (character)
    //     {
    //         case Character.Player:
    //             currentConfig = qingxuConfig;
    //             break;
    //         case Character.Cat:
    //             currentConfig = catConfig;
    //             break;
    //         default:
    //             currentConfig = qingxuConfig;
    //             break;
    //     }
    //
    //     // 更新外观
    //     SetAnimator(currentConfig.animator);
    //     SetSprite(currentConfig.bodySprite);
    //
    //     // 更新数据
    //     moveSpeed = currentConfig.moveSpeed;
    //     jumpForce = currentConfig.jumpForce;
    //
    //
    //     // 更新碰撞体
    //     var col = GetComponent<CapsuleCollider2D>();
    //     col.offset = currentConfig.colliderOffset;
    //     col.size = currentConfig.colliderSize;
    // }
    //
    // public void SetAnimator(RuntimeAnimatorController controller)
    // {
    //     anim.runtimeAnimatorController = controller;
    // }
    //
    // public void SetSprite(Sprite body)
    // {
    //     spriteRenderer.sprite = body;
    // }

#endregion

#region 角色运动控制

    public void SetVelocity(float x, float y)
    {
        rb.velocity = new Vector2(x, y);
        physics.FlipController(x);
    }

    public void StopMove()
    {
        rb.velocity = Vector2.zero;
    }

#endregion


    private void OnEnable()
    {
        inputActions.FindActionMap("Player").Enable();
        //EventHandler.GamePhaseChangeEvent += OnGameStateChanged;
        //EventHandler.AfterSceneLoadEvent += OnLoadNewScene;
    }

    private void OnDisable()
    {
        inputActions.FindActionMap("Player").Disable();
        //EventHandler.GamePhaseChangeEvent -= OnGameStateChanged;
        //EventHandler.AfterSceneLoadEvent -= OnLoadNewScene;
    }
}