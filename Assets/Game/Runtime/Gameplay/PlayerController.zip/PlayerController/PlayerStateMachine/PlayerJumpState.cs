using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerJumpState : PlayerState
{
    // Start is called before the first frame update
    public PlayerJumpState(Player player, PlayerStateMachine stateMachine, string animBoolName) : base(player, stateMachine,
        animBoolName)
    {
    }

    public override void Enter()
    {
        base.Enter();
        rb.velocity = new Vector2(rb.velocity.x, Player.jumpForce);
    }

    public override void Update()
    {
        base.Update();
        if (rb.velocity.y <= 0)
        {
            stateMachine.ChangeState(Player.airState);
        }
    }

    public override void Exit()
    {
        base.Exit();
    }
}