using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAirState : PlayerState
{
    public PlayerAirState(Player player, PlayerStateMachine stateMachine, string animBoolName) : base(player, stateMachine,
        animBoolName)
    {
    }

    public override void Enter()
    {
        base.Enter();
    }

    public override void Update()
    {
        base.Update();
        if (Player.physics.IsWall())
        {
            Player.SetVelocity(0, rb.velocity.y * 1.05f);
        }

        if (Player.physics.IsGrounded() && !Player.physics.IsFalling)
        {
            stateMachine.ChangeState(Player.idleState);
        }

        if (xInput != 0)
        {
            Player.SetVelocity(xInput * Player.moveSpeed * 0.8f, rb.velocity.y);
        }
    }

    public override void Exit()
    {
        base.Exit();
    }
}