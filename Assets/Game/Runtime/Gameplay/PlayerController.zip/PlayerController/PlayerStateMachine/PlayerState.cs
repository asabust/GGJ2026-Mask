using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class PlayerState
{
    protected PlayerStateMachine stateMachine;
    protected Player Player;
    protected Rigidbody2D rb;

    protected float xInput;
    protected float yInput;
    private string animBoolName;

    protected float stateTimer;
    protected bool triggerCalled;

    public PlayerState(Player player, PlayerStateMachine stateMachine, string animBoolName)
    {
        this.Player = player;
        this.stateMachine = stateMachine;
        this.animBoolName = animBoolName;
    }

    public virtual void Enter()
    {
        rb = Player.rb;
        Player.anim.SetBool(animBoolName, true);
        Player.catAnim.SetBool(animBoolName, true);
        Player.shadow.SetBool(animBoolName, true);
        triggerCalled = false;
    }

    public virtual void Update()
    {
        xInput = Player.moveInputValue.x;
        yInput = Player.moveInputValue.y;
        Player.anim.SetFloat("yVelocity", rb.velocity.y);
        Player.catAnim.SetFloat("yVelocity", rb.velocity.y);
        Player.shadow.SetFloat("yVelocity", rb.velocity.y);
        stateTimer -= Time.deltaTime;
    }

    public virtual void Exit()
    {
        Player.anim.SetBool(animBoolName, false);
        Player.catAnim.SetBool(animBoolName, false);
        Player.shadow.SetBool(animBoolName, false);
    }

    public virtual void AnimationFinishedTrigger()
    {
        triggerCalled = true;
    }
}