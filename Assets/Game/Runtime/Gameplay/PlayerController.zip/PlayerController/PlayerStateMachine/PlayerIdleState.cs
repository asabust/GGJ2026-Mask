using System.Collections;
using System.Collections.Generic;
using Game.Runtime.Core;
using UnityEngine;

public class PlayerIdleState : PlayerGroundState
{
    public PlayerIdleState(Player player, PlayerStateMachine stateMachine, string animBoolName) : base(player, stateMachine,
        animBoolName)
    {
    }

    public override void Enter()
    {
        base.Enter();
        Player.StopMove();
    }

    public override void Update()
    {
        base.Update();

        if (xInput * Player.physics.facingDir > 0 && Player.physics.IsWall()) return;
        if (GameManager.Instance.CurrentPhase == GamePhase.Gameplay && xInput != 0)
        {
            stateMachine.ChangeState(Player.moveState);
        }

        rb.velocity = new Vector2(0f, rb.velocity.y);
    }

    public override void Exit()
    {
        base.Exit();
    }
}