using System.Collections;
using System.Collections.Generic;
using Game.Runtime.Core;
using UnityEngine;

public class PlayerGroundState : PlayerState
{
    public PlayerGroundState(Player player, PlayerStateMachine stateMachine, string animBoolName) : base(player, stateMachine,
        animBoolName)
    {
    }

    public override void Enter()
    {
        base.Enter();
    }

    public override void Update()
    {
        base.Update();
        // 跳跃功能
        // if (Player.jumpAction.WasPressedThisFrame())
        // {
        //     if (yInput < -0.5f && Player.physics.IsFallThroughGround())
        //     {
        //         stateMachine.ChangeState(Player.airState);
        //     }
        //     else
        //     {
        //         stateMachine.ChangeState(Player.jumpState);
        //     }
        // }
    }

    public override void Exit()
    {
        base.Exit();
    }
}