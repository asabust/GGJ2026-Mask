using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PhysicsDetection : MonoBehaviour
{
    // [Header("交互物检测")]
    // public Transform interactCheck;
    // public float interactRadius;
    // [SerializeField] protected LayerMask interactLayer;
    [Header("地面检测")]
    [SerializeField] protected Transform groundCheck;
    [SerializeField] protected float groundCheckDistance = 0.4f;
    [SerializeField] protected Transform wallCheck;
    [SerializeField] protected float wallCheckDistance = 0.4f;
    [SerializeField] protected LayerMask groundLayer;

    private Collider2D catCollider;
    private Collider2D[] hits = new Collider2D[8];

    public int facingDir { get; private set; } = 1;
    private bool facingRight = true;

    public bool IsFalling { get; private set; } = false;

    private void Awake()
    {
        catCollider = GetComponent<Collider2D>();
    }

#region 搜查物

    // public InteractableBase CheckForInteractable()
    // {
    //     var count = Physics2D.OverlapCircleNonAlloc(interactCheck.position, interactRadius, hits, interactLayer);
    //
    //     if (count > 0)
    //     {
    //         InteractableBase closest = null;
    //         float minDist = Mathf.Infinity;
    //
    //         foreach (var hit in hits)
    //         {
    //             InteractableBase s = hit.GetComponent<InteractableBase>();
    //             if (!s) continue;
    //             float dist = Vector2.Distance(transform.position, s.transform.position);
    //             if (dist < minDist)
    //             {
    //                 minDist = dist;
    //                 closest = s;
    //             }
    //         }
    //
    //         return closest;
    //     }
    //
    //     return null;
    // }

#endregion

#region 翻转

    public void Flip()
    {
        facingDir *= -1;
        facingRight = !facingRight;
        transform.Rotate(0, 180, 0);
    }

    public void FlipController(float _x)
    {
        if ((_x > 0 && !facingRight) || (_x < 0 && facingRight))
            Flip();
    }

#endregion

#region 地面检测

    public bool IsFallThroughGround()
    {
        Collider2D groundBelow = GetGroundBelow();
        if (groundBelow && !groundBelow.gameObject.CompareTag("Ground"))
        {
            StartCoroutine(FallThrough(groundBelow));
            return true;
        }

        return false;
    }

    IEnumerator FallThrough(Collider2D groundBelow)
    {
        IsFalling = true;
        Physics2D.IgnoreCollision(catCollider, groundBelow, true);
        yield return new WaitForSeconds(0.3f);
        Physics2D.IgnoreCollision(catCollider, groundBelow, false);
        IsFalling = false;
    }

    public Collider2D GetGroundBelow() => Physics2D.OverlapCircle(groundCheck.position, 0.1f, groundLayer);

    public virtual bool IsGrounded() =>
        Physics2D.Raycast(groundCheck.position, Vector2.down, groundCheckDistance, groundLayer);

    public virtual bool IsWall() =>
        Physics2D.Raycast(wallCheck.position, Vector2.right * facingDir, wallCheckDistance, groundLayer);

#endregion

    protected virtual void OnDrawGizmos()
    {
        Gizmos.DrawLine(groundCheck.position,
            new Vector3(groundCheck.position.x, groundCheck.position.y - groundCheckDistance));
        Gizmos.DrawLine(wallCheck.position,
            new Vector3(wallCheck.position.x + wallCheckDistance * facingDir, wallCheck.position.y));
        //Gizmos.DrawWireSphere(interactCheck.position, interactRadius);
    }
}